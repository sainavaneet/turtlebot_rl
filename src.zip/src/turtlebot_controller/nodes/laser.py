import rospy
import numpy as np
from geometry_msgs.msg import Twist, Pose
from nav_msgs.msg import Odometry
from collections import deque
from tf.transformations import euler_from_quaternion
from std_srvs.srv import Empty
import random
import torch
import torch.nn as nn
import torch.optim as optim
from sensor_msgs.msg import LaserScan
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# Define the Q-network
class QNetwork(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, output_dim)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

class RobotController:
    def __init__(self):
        rospy.init_node('robot_rl_controller')
        rospy.Subscriber('/robot1/odom', Odometry, self.robot1_odom_callback)
        rospy.Subscriber('/robot2/odom', Odometry, self.robot2_odom_callback)
        rospy.Subscriber('/robo2/scan', LaserScan, self.robot2_scan_callback)

        
        self.cmd_vel_robot2 = rospy.Publisher('/robot2/cmd_vel', Twist, queue_size=10)
        self.cmd_vel_robot1 = rospy.Publisher('/robot1/cmd_vel', Twist, queue_size=10)

        # Define robot reset publishers (you need to create these topics)
        self.robot1_reset_publisher = rospy.Publisher('/robot1/pose_reset', Pose, queue_size=1)
        self.robot2_reset_publisher = rospy.Publisher('/robot2/pose_reset', Pose, queue_size=1)
        self.reset_proxy = rospy.ServiceProxy('gazebo/reset_simulation', Empty)
        self.unpause_proxy = rospy.ServiceProxy('gazebo/unpause_physics', Empty)
        self.pause_proxy = rospy.ServiceProxy('gazebo/pause_physics', Empty)

        self.memory = deque(maxlen=10000)
        self.gamma = 0.99
        self.learning_rate = 0.001
        self.epsilon = 1.0
        self.epsilon_decay = 0.995
        self.min_epsilon = 0.01
        self.collided = False

        
        self.q_network = QNetwork(6, 3).to(device)
        self.target_network = QNetwork(6, 3).to(device)

        self.optimizer = optim.Adam(self.q_network.parameters(), lr=self.learning_rate)

    def get_state(self):
        return np.array([self.robot1_x, self.robot1_y, self.robot1_theta, self.robot2_x, self.robot2_y, self.robot2_theta])

    def get_reward(self):
        # Custom reward function, for simplicity, distance between two robots
        dist = np.sqrt((self.robot1_x - self.robot2_x)**2 + (self.robot1_y - self.robot2_y)**2)
        return -dist

    def choose_action(self, state):
        state_np = np.array(state).reshape(1, -1)
        state_tensor = torch.FloatTensor(state_np).to(device)

        if np.random.rand() < self.epsilon:
            return np.random.choice([0, 1, 2])  # Include 0, 1, and 2 for straight, left, and right

        with torch.no_grad():
            return np.argmax(self.q_network(state_tensor).cpu().data.numpy())

    def robot1_odom_callback(self, data):
        self.robot1_x = data.pose.pose.position.x
        self.robot1_y = data.pose.pose.position.y
        orientation = data.pose.pose.orientation
        (_, _, self.robot1_theta) = euler_from_quaternion([orientation.x, orientation.y, orientation.z, orientation.w])
    
    def robot2_odom_callback(self, msg):
        self.robot2_x = msg.pose.pose.position.x
        self.robot2_y = msg.pose.pose.position.y
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot2_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])
        
    from sensor_msgs.msg import LaserScan

    def robot2_scan_callback(self, data):
        # Assuming that the laser scan returns ranges in a 360-degree fashion
        if any(distance < 0.1 for distance in data.ranges):  # 0.2 is a threshold that you might want to tune
            print("Collide!")
            self.collided = True
        else:
            self.collided = False


    def train(self):
        if len(self.memory) < 64:
            return

        batch = random.sample(self.memory, 64)
        state, action, reward, next_state, done = zip(*batch)
        state = torch.FloatTensor(state).to(device)
        action = torch.LongTensor(action).to(device)
        reward = torch.FloatTensor(reward).to(device)
        next_state = torch.FloatTensor(next_state).to(device)
        done = torch.FloatTensor(done).to(device)

        q_values = self.q_network(state)
        next_q_values = self.q_network(next_state)
        next_q_target = self.target_network(next_state)
        
        q_value = q_values.gather(1, action.unsqueeze(1)).squeeze(1)
        next_q_value = next_q_target.gather(1, torch.max(next_q_values, 1)[1].unsqueeze(1)).squeeze(1)
        expected_q_value = reward + self.gamma * next_q_value * (1 - done)
        
        loss = (q_value - expected_q_value.detach()).pow(2).mean()
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        self.epsilon = max(self.epsilon * self.epsilon_decay, self.min_epsilon)

    def reset_environment(self):
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
        return self.get_state()

    def step(self, action):
        control_command_robot2 = Twist()

        if action == 0:  # Straight
            control_command_robot2.linear.x = 0.2
        elif action == 1:  # Left
            control_command_robot2.angular.z = 0.2
        elif action == 2:  # Right
            control_command_robot2.angular.z = -0.2

        self.cmd_vel_robot2.publish(control_command_robot2)
        control_command_robot1 = Twist()
        control_command_robot1.linear.x = 0.1
        control_command_robot1.angular.z = 0.1  
        self.cmd_vel_robot1.publish(control_command_robot1)
        
        # Simulate/observe the action effect for 0.1 seconds
        rospy.sleep(0.1)

        next_state = self.get_state()
        reward = self.get_reward()
        done = False
        
        return next_state, reward, done

    def check_distance(self):
        dist = np.sqrt((self.robot1_x - self.robot2_x)**2 + (self.robot1_y - self.robot2_y)**2)
        return dist

    def reset_robots_if_needed(self):
        if self.check_distance():
            self.reset_robot1()
            self.reset_robot2()

    def reset_robot1(self):
        reset_pose = Pose()
        reset_pose.position.x = 0.0
        reset_pose.position.y = 0.0
        reset_pose.position.z = 0.0
        reset_pose.orientation.x = 0.0
        reset_pose.orientation.y = 0.0
        reset_pose.orientation.z = 0.0
        reset_pose.orientation.w = 1.0
        self.robot1_reset_publisher.publish(reset_pose)
    def reset(self):
        rospy.wait_for_service('gazebo/reset_simulation')
        try:
            self.reset_proxy()
        except (rospy.ServiceException) as e:
            print("gazebo/reset_simulation service call failed")


    def reset_robot2(self):
        reset_pose = Pose()
        reset_pose.position.x = -1.0
        reset_pose.position.y = 0.0
        reset_pose.position.z = 0.0
        reset_pose.orientation.x = 0.0
        reset_pose.orientation.y = 0.0
        reset_pose.orientation.z = 0.0
        reset_pose.orientation.w = 1.0
        self.robot2_reset_publisher.publish(reset_pose)

    def save_model(self, path):
        torch.save(self.q_network.state_dict(), path)

    def control_loop(self):
        epochs = 1000  
        max_episode_steps = 500  
        for epoch in range(epochs):
            state = self.reset_environment()
            done = False
            episode_reward = 0
            step_count = 0

            while not done:
                action = self.choose_action(state)
                next_state, reward, done = self.step(action)
                self.memory.append((state, action, reward, next_state, done))
                episode_reward += reward
                self.train()
                state = next_state
                dist = self.check_distance()
                step_count += 1
                
                if self.check_distance() > 3.0 or self.check_distance() < 0.1:
                    print("Resetting Gazebo simulation due to large distance between robots...")
                    try:
                        self.reset_proxy()
                    except rospy.ServiceException as e:
                        print("Failed to reset Gazebo simulation:", str(e))
                    self.memory.clear()  
                    break
                      
                if step_count >= max_episode_steps:
                    break
            
                print(f"Episode: {epoch+1},step : {step_count},action : {action},Distance : {dist} ,Reward: {episode_reward}")

            if epoch % 10 == 0:
                self.target_network.load_state_dict(self.q_network.state_dict())
            
            if (epoch + 1) % 100 == 0:
                self.save_model("/home/navaneet/my_ws/src/turtlebot_controller/nodes/save_model/model_epoch_{}.pth".format(epoch + 1))


if __name__ == '__main__':
    try:
        controller = RobotController()
        controller.control_loop()
    except rospy.ROSInterruptException:
        rospy.signal_shutdown("Ctrl+C pressed. Stopping robots.")
        pass
