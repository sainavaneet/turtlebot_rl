import rospy
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from gym import spaces

import numpy as np
class FollowEnv:

    def __init__(self):
        rospy.init_node('follow_env', anonymous=True)

        self.odom_sub = rospy.Subscriber('/robot1/odom', Odometry, self.odom_callback)
        self.cmd_vel_pub = rospy.Publisher('/robot2/cmd_vel', Twist, queue_size=10)
        
        # The action will be a Twist message: linear x and angular z
        self.action_space = spaces.Box(low=-1, high=1, shape=(2,), dtype=float)
        
        # Assuming state is the pose (x, y, yaw) of robot1
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(3,), dtype=float)

        self.current_odom = None

    def odom_callback(self, data):
        self.current_odom = data

    def step(self, action):
        if not self.current_odom:
            return None, 0, True, {}
        
        # Transform action to cmd_vel and send to robot2
        cmd_vel = Twist()
        cmd_vel.linear.x = action[0]
        cmd_vel.angular.z = action[1]
        self.cmd_vel_pub.publish(cmd_vel)
        
        # State will be the pose (x, y, yaw) of robot1
        state = [self.current_odom.pose.pose.position.x, self.current_odom.pose.pose.position.y, 
                 2 * np.arctan2(self.current_odom.pose.pose.orientation.z, 
                                self.current_odom.pose.pose.orientation.w)] # This converts quaternion to yaw
        
        # Here, define your reward and done logic based on the position of robot1 and robot2
        # For simplicity:
        reward = -np.linalg.norm(np.array(state))
        done = False
        if reward > -0.1:  # If robot2 is very close to robot1
            done = True

        return state, reward, done, {}

    def reset(self):
        # Reset the environment, if needed
        pass
