import math

# Define follower robot's state (position and orientation)
follower_x = 0.0
follower_y = 0.0
follower_theta = 0.0


leader_radius = 5.0
leader_angular_speed = 0.5  # radians per second

kp = 1.0  # Proportional gain


simulation_time = 100  # seconds
time_step = 0.1  # seconds

file_path = "follower_positions.txt"

with open(file_path, "w") as file:
    for t in range(int(simulation_time / time_step)):
        dx = leader_radius * math.cos(leader_angular_speed * t * time_step) - follower_x
        dy = leader_radius * math.sin(leader_angular_speed * t * time_step) - follower_y
        desired_theta = math.atan2(dy, dx)

        delta_theta = desired_theta - follower_theta
        delta_theta = math.atan2(math.sin(delta_theta), math.cos(delta_theta))  # Normalize angle
        control_input = kp * delta_theta

        follower_x += math.cos(follower_theta) * control_input * time_step
        follower_y += math.sin(follower_theta) * control_input * time_step
        follower_theta += control_input * time_step

        file.write(f"Time: {t * time_step:.2f}, Follower Pose: ({follower_x:.2f}, {follower_y:.2f}, {follower_theta:.2f})\n")
