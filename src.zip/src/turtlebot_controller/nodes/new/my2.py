import math
import csv

# Define follower and leader robot's states (position and orientation)
follower_x = -1.0
follower_y = 0.0
follower_theta = 0.0

leader_x = leader_radius = 5.0  # Start at the initial point of the circular path
leader_y = 0.0
leader_theta = 0.0

# Define leader's trajectory (circular path)
leader_radius = 5.0
leader_angular_speed = 0.5  # radians per second

# Control gains (adjust as needed)
kp = 1.0  # Proportional gain
kd = 1.0  # Derivative gain (for state feedback linearization)

# Robot's velocities
v = 1.0  # Linear velocity (adjust as needed)
omega = 0.0  # Angular velocity (adjust as needed)

# Simulation parameters
simulation_time = 100  # seconds
time_step = 0.1  # seconds

# File paths to save follower and leader positions in CSV format
follower_file_path = "follower_positions.csv"
leader_file_path = "leader_positions.csv"

# Create CSV files and write headers
with open(follower_file_path, "w", newline="") as follower_file, open(leader_file_path, "w", newline="") as leader_file:
    follower_writer = csv.writer(follower_file)
    leader_writer = csv.writer(leader_file)

    # Write headers to CSV files
    follower_writer.writerow(["Time", "Follower_X", "Follower_Y", "Follower_Theta"])
    leader_writer.writerow(["Time", "Leader_X", "Leader_Y", "Leader_Theta"])

    for t in range(int(simulation_time / time_step)):
        # Calculate distance and angle to leader robot
        dx = leader_radius * math.cos(leader_angular_speed * t * time_step) - follower_x
        dy = leader_radius * math.sin(leader_angular_speed * t * time_step) - follower_y
        desired_theta = math.atan2(dy, dx)

        # Calculate control inputs
        delta_theta = desired_theta - follower_theta
        delta_theta = math.atan2(math.sin(delta_theta), math.cos(delta_theta))  # Normalize angle
        control_input = -kp * delta_theta - kd * (omega - leader_angular_speed)

        # Update the follower's state directly based on state feedback linearization
        follower_x_dot = v * math.cos(follower_theta)
        follower_y_dot = v * math.sin(follower_theta)
        follower_theta_dot = omega

        follower_x += follower_x_dot * time_step
        follower_y += follower_y_dot * time_step
        follower_theta += follower_theta_dot * time_step

        # Update leader's position on the circular path
        leader_x = leader_radius * math.cos(leader_angular_speed * t * time_step)
        leader_y = leader_radius * math.sin(leader_angular_speed * t * time_step)
        leader_theta = leader_angular_speed * t * time_step

        # Write follower's position data to the follower CSV file
        follower_writer.writerow([t * time_step, follower_x, follower_y, follower_theta])

        # Write leader's position data to the leader CSV file
        leader_writer.writerow([t * time_step, leader_x, leader_y, leader_theta])
