




#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
import math

class RobotController:
    def __init__(self):
        rospy.init_node('robot_controller')
        
        rospy.Subscriber('/robot1/odom', Odometry, self.robot1_odom_callback)
        rospy.Subscriber('/robot2/odom', Odometry, self.robot2_odom_callback)
        
        self.cmd_vel_robot2 = rospy.Publisher('/robot2/cmd_vel', Twist, queue_size=10)
        self.cmd_vel_robot1 = rospy.Publisher('/robot1/cmd_vel', Twist, queue_size=10)

        self.robot1_x = 0.0
        self.robot1_y = 0.0
        self.robot1_theta = 0.0
        self.robot2_x = 0.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0

        self.k_x =  0.5
        self.k_theta = 0.5

    def robot1_odom_callback(self, msg):
        self.robot1_x = msg.pose.pose.position.x
        self.robot1_y = msg.pose.pose.position.y
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot1_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def robot2_odom_callback(self, msg):
        self.robot2_x = msg.pose.pose.position.x
        self.robot2_y = msg.pose.pose.position.y
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot2_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def control_loop(self):
        rate = rospy.Rate(30)  # 30 Hz control loop
        while not rospy.is_shutdown():
            x_d_robot2 = self.robot1_x
            y_d_robot2 = self.robot1_y
            theta_d_robot2 = self.robot1_theta
            
            x_error_robot2 = x_d_robot2 - self.robot2_x
            y_error_robot2 = y_d_robot2 - self.robot2_y
            theta_error_robot2 = theta_d_robot2 - self.robot2_theta

            if theta_error_robot2 > math.pi:
                theta_error_robot2 -= 2.0 * math.pi
            elif theta_error_robot2 < -math.pi:
                theta_error_robot2 += 2.0 * math.pi

            linear_vel_robot2 = self.k_x * math.sqrt(x_error_robot2**2 + y_error_robot2**2)

            angular_vel_robot2 = self.k_theta * theta_error_robot2

            control_command_robot1 = Twist()
            control_command_robot1.linear.x = 0.5
            control_command_robot1.angular.z = 0.5  
            self.cmd_vel_robot1.publish(control_command_robot1)

            control_command_robot2 = Twist()
            control_command_robot2.linear.x = linear_vel_robot2
            control_command_robot2.angular.z = angular_vel_robot2
            self.cmd_vel_robot2.publish(control_command_robot2)

            rate.sleep()

if __name__ == '__main__':
    try:
        controller = RobotController()
        controller.control_loop()
    except rospy.ROSInterruptException:
        pass
