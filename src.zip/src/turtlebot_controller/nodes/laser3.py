import rospy
import numpy as np
from geometry_msgs.msg import Twist, Pose
from nav_msgs.msg import Odometry
from collections import deque
from tf.transformations import euler_from_quaternion
from std_srvs.srv import Empty
import random
import torch
import torch.nn as nn
import torch.optim as optim
from sensor_msgs.msg import LaserScan

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class QNetwork(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, output_dim)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

class RobotController:
    def __init__(self):


        self.initialize_ros_nodes()
        self.dist = self.get_distance()

    def initialize_ros_nodes(self):
        rospy.init_node('robot_rl_controller')
        rospy.Subscriber('/robot1/odom', Odometry, self.robot1_odom_callback)
        rospy.Subscriber('/robot2/odom', Odometry, self.robot2_odom_callback)
        self.cmd_vel_robot2 = rospy.Publisher('/robot2/cmd_vel', Twist, queue_size=10)
        self.cmd_vel_robot1 = rospy.Publisher('/robot1/cmd_vel', Twist, queue_size=10)
        self.reset_proxy = rospy.ServiceProxy('gazebo/reset_simulation', Empty)
        self.unpause_proxy = rospy.ServiceProxy('gazebo/unpause_physics', Empty)
        self.pause_proxy = rospy.ServiceProxy('gazebo/pause_physics', Empty)
        self.gamma = 0.97
        self.learning_rate = 0.00025
        self.epsilon_decay = 0.998
        self.min_epsilon = 0.005
        self.memory = deque(maxlen=1000000)
        self.epsilon = 1.0
        self.robot1_x = 0
        self.robot1_y = 0
        self.robot1_theta = 0.0
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
        self.min_laser_distance = float('inf')
        self.q_network = QNetwork(6, 5).to(device)
        self.target_network = QNetwork(6, 5).to(device)
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=self.learning_rate)

        


    def get_state(self):
        return np.array([self.robot1_x, self.robot1_y, self.robot1_theta, self.robot2_x, self.robot2_y, self.robot2_theta])


    def get_reward(self):
        self.get_distance()
        orientation_reward = np.cos(self.robot2_theta - self.robot1_theta)  
        
        if self.dist < 0.2:
            return -1000  
        return -self.dist + 10 * orientation_reward 

    def choose_action(self, state):
        state_np = np.array(state).reshape(1, -1)
        state_tensor = torch.FloatTensor(state_np).to(device)

        if np.random.rand() < self.epsilon:
            return np.random.choice([0, 1, 2 , 3 , 4])  

        with torch.no_grad():
            return np.argmax(self.q_network(state_tensor).cpu().data.numpy())
        

    def robot1_odom_callback(self, msg):
        self.robot1_x = msg.pose.pose.position.x
        self.robot1_y = msg.pose.pose.position.y
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot1_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def robot2_odom_callback(self, msg):
        self.robot2_x = msg.pose.pose.position.x
        self.robot2_y = msg.pose.pose.position.y
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot2_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def get_distance(self):
        x1 = self.robot1_x
        y1 = self.robot1_y
        x2 = self.robot2_x
        y2 = self.robot2_y
        self.dist = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        return self.dist
    

    def train(self):

        batch_size = 128
        if len(self.memory) < batch_size:
            return

        batch = random.sample(self.memory, batch_size)

    
        state, action, reward, next_state, done = zip(*batch)
        state = torch.FloatTensor(np.array(state)).to(device)
        action = torch.LongTensor(action).to(device)
        reward = torch.FloatTensor(reward).to(device)
        next_state = torch.FloatTensor(np.array(next_state)).to(device)
        done = torch.FloatTensor(done).to(device)

        q_values = self.q_network(state)
        next_q_values = self.q_network(next_state)
        next_q_target = self.target_network(next_state)
        
        q_value = q_values.gather(1, action.unsqueeze(1)).squeeze(1)
        next_q_value = next_q_target.gather(1, torch.max(next_q_values, 1)[1].unsqueeze(1)).squeeze(1)
        expected_q_value = reward + self.gamma * next_q_value * (1 - done)
        
        loss = (q_value - expected_q_value.detach()).pow(2).mean()
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.epsilon = max(self.epsilon * self.epsilon_decay, self.min_epsilon)

        return loss.item()

    def reset_environment(self):
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
        return self.get_state()

    def step(self, action):
        control_command_robot2 = Twist()

        if action == 0:  # Straight
            control_command_robot2.linear.x = 0.2
        elif action == 1:  # Left
            control_command_robot2.angular.z = 0.2
        elif action == 2:  # Right
            control_command_robot2.angular.z = -0.2
        elif action == 3:  # Slow Down
            control_command_robot2.linear.x = 0.05
        elif action == 4:  # Stop
            control_command_robot2.linear.x = 0.0

        self.cmd_vel_robot2.publish(control_command_robot2)
        control_command_robot1 = Twist()
        control_command_robot1.linear.x = 0.2
        control_command_robot1.angular.z = 0.2  
        self.cmd_vel_robot1.publish(control_command_robot1)
        
        rospy.sleep(0.1)

        next_state = self.get_state()
        reward = self.get_reward()
        done = False
        return next_state, reward, done
    def reset(self):
        rospy.wait_for_service('gazebo/reset_simulation')
        try:
            self.reset_proxy()
        except (rospy.ServiceException) as e:
            rospy.logerr("gazebo/reset_simulation service call failed")
        
    def save_model(self, path):
        torch.save(self.q_network.state_dict(), path)
        
    def safe_sleep(self , duration):
        
        try:
            rospy.sleep(duration)
        except rospy.exceptions.ROSTimeMovedBackwardsException:
            pass

    def control_loop(self):
        max_episode_steps = 1000  
        self.get_distance()
        loss = self.train()
        loss = None
        epoch = 0
        while not rospy.is_shutdown():  
            state = self.reset_environment()
            done = False
            episode_reward = 0
            step_count = 0

            while not done:
                action = self.choose_action(state)
                next_state, reward, done = self.step(action)
                self.memory.append((state, action, reward, next_state, done))
                episode_reward += reward
                state = next_state
                step_count += 1
                temp_loss = self.train()

                if temp_loss is not None:
                    loss = temp_loss
        
                if self.dist < 0.3 or self.dist > 3.0 or step_count >= max_episode_steps or  episode_reward < -1000:
                    rospy.loginfo("Resetting due to distance or collision or maximum steps reached ------------------->>>>>>>!!!!!!!")
                    self.reset()
                    break
                rospy.loginfo(f"Episode: {epoch+1}, step: {step_count}, action: {action}, Distance: {self.dist}, Reward: {episode_reward}")

            if epoch % 10 == 0:
                self.target_network.load_state_dict(self.q_network.state_dict())

            
            if (epoch + 1) % 100 == 0:
                self.save_model("/home/navaneet/my_ws/src/turtlebot_controller/nodes/save_model2/model_epoch_{}.pth".format(epoch + 1))

            epoch += 1
            
            self.safe_sleep(0.1)

if __name__ == '__main__':
    try:
        controller = RobotController()
        controller.q_network.load_state_dict(torch.load('/home/navaneet/my_ws/src/turtlebot_controller/nodes/save_model2/model_epoch_6800.pth'))
        controller.control_loop()
    except rospy.ROSInterruptException:
        rospy.signal_shutdown("Ctrl+C pressed. Stopping robots.")
        pass
