import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from collections import deque
import random
from keras.optimizers import Adam
import rospy
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from gym import spaces

class FollowEnv:
    def __init__(self):
        # rospy.init_node('follow_env', anonymous=True)

        self.odom_sub = rospy.Subscriber('/robot1/odom', Odometry, self.odom_callback)
        self.cmd_vel_pub = rospy.Publisher('/robot2/cmd_vel', Twist, queue_size=10)
        self.cmd_vel_pub_1 = rospy.Publisher('/robot1/cmd_vel', Twist, queue_size=10)

        self.action_size = 5
        self.action_space = spaces.Discrete(self.action_size)
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(3,), dtype=float)
        self.current_odom = None

    def odom_callback(self, data):
        self.current_odom = data

    def step(self, action):
        if not self.current_odom:
            return None, 0, True, {}

        max_angular_vel = 1.5
        ang_vel = ((self.action_size - 1)/2 - action) * max_angular_vel * 0.5

        cmd_vel = Twist()
        cmd_vel.linear.x = 0.15
        cmd_vel.angular.z = ang_vel
        self.cmd_vel_pub.publish(cmd_vel)

        cmd_vel_1 = Twist()
        cmd_vel_1.linear.x = 0.2
        cmd_vel_1.angular.z = 0.2
        # self.cmd_vel_pub_1.publish(cmd_vel_1)

        state = [self.current_odom.pose.pose.position.x, self.current_odom.pose.pose.position.y, 
                 2 * np.arctan2(self.current_odom.pose.pose.orientation.z, self.current_odom.pose.pose.orientation.w)]
        reward = -np.linalg.norm(np.array(state))
        done = False
        if reward > -0.1:
            done = True

        return state, reward, done, {}

    def reset(self):
        state = [0.0, 0.0, 0.0]  # replace with actual state logic
        return state

class DQNAgent:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95
        self.epsilon = 1.0
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = 0.001
        self.model = self._build_model()
        self.target_model = self._build_model()
        self.update_target_model()

    def _build_model(self):
        model = Sequential()
        model.add(Dense(24, input_dim=self.state_size, activation='relu'))
        model.add(Dense(24, activation='relu'))
        model.add(Dense(self.action_size, activation='linear'))
        model.compile(loss='mse', optimizer=Adam(lr=self.learning_rate))
        return model

    def update_target_model(self):
        self.target_model.set_weights(self.model.get_weights())

    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def act(self, state):
        state = np.array(state).reshape(1, -1)
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)
        act_values = self.model.predict(state)
        return np.argmax(act_values[0])

    def replay(self, batch_size):
        minibatch = random.sample(self.memory, batch_size)
        for state, action, reward, next_state, done in minibatch:
            state = np.array(state).reshape(1, -1)
            target = self.model.predict(state)
            if done:
                target[0][action] = reward
            else:
                next_state_reshaped = np.expand_dims(next_state, axis=0)
                Q_future = np.amax(self.target_model.predict(next_state_reshaped)[0])
                target[0][action] = reward + self.gamma * Q_future
            self.model.train_on_batch(state, target)
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

if __name__ == "__main__":
    rospy.init_node('dqn_agent')

    env = FollowEnv()
    state_size = env.observation_space.shape[0]
    action_size = env.action_space.n
    
    agent = DQNAgent(state_size, action_size)
    batch_size = 32
    
    
    
    


    for e in range(1000):  # Number of episodes
        state = env.reset()
        print("Reset State:", state)

        for time in range(500):  # Max timestep in an episode
            action = agent.act(state)
            next_state, reward, done, _ = env.step(action)
            if next_state is None:
                break
            agent.remember(state, action, reward, next_state, done)
            state = next_state
            if done:
                agent.update_target_model()
                break

            if len(agent.memory) > batch_size:
                agent.replay(batch_size)
