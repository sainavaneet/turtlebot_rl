import numpy as np
import matplotlib.pyplot as plt

def compute_velocities(A, T, num_steps=1000):
    delta_t = T / num_steps
    velocities = []

    for i in range(num_steps):
        t = i * delta_t
        x_dot = A * np.cos(t)
        y_dot = A * np.cos(t) - A * np.sin(t)**2
        
        v = np.sqrt(x_dot**2 + y_dot**2)
        omega = np.arctan2(y_dot, x_dot)

        # Clamp the velocities
        v = np.clip(v, 0.05, 0.2)
        omega = np.clip(omega, 0.05, 0.2)

        velocities.append((v, omega))

    return velocities

def save_to_file(filename, velocities):
    with open(filename, 'w') as file:
        file.write("Linear Velocity,Angular Velocity\n")
        for v in velocities:
            file.write(f"{v[0]},{v[1]}\n")

A = 1.0  # You can adjust this value
T = 20.0  # You can adjust this value

velocities = compute_velocities(A, T)

# Saving to a file named "velocities.csv"
save_to_file("velocities.txt", velocities)

# Plotting for visualization
v_values = [v[0] for v in velocities]
omega_values = [v[1] for v in velocities]

plt.figure(figsize=(12, 6))
plt.subplot(2, 1, 1)
plt.plot(v_values, label='Linear Velocity (v)')
plt.legend()
plt.subplot(2, 1, 2)
plt.plot(omega_values, label='Angular Velocity (omega)', color='r')
plt.legend()
plt.show()
