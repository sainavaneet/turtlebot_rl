import rospy
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist


def Robto(self):
    
    
    self.odom_sub = rospy.Subscriber('/robot1/odom', Odometry, self.odom_callback)
    cmd_vel_1 = Twist()
    cmd_vel_1.linear.x = 0.2
    cmd_vel_1.angular.z = 0.2
    self.cmd_vel_pub_1.publish(cmd_vel_1)