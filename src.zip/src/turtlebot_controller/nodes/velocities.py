import numpy as np

# Read the points from the file
with open("lemniscate_points.txt", "r") as f:
    points = [tuple(map(float, line.strip().split(", "))) for line in f]

# Calculate the linear and angular velocities
linear_velocities = []
angular_velocities = []

for i in range(1, len(points)):
    x_error_12 = points[i][0] - points[i-1][0]
    y_error_12 = points[i][1] - points[i-1][1]
    
    linear_velocity = np.sqrt(x_error_12**2 + y_error_12**2)
    angular_velocity = np.arctan2(y_error_12, x_error_12)
    
    linear_velocities.append(linear_velocity)
    angular_velocities.append(angular_velocity)

# Save the velocities to a new file
with open("velocities.txt", "w") as f:
    f.write("Linear Velocity, Angular Velocity\n")
    for lv, av in zip(linear_velocities, angular_velocities):
        f.write(f"{lv}, {av}\n")

print("Velocities saved to velocities.txt")
