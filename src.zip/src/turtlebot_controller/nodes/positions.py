#!/usr/bin/env python3

import rospy
import csv
from geometry_msgs.msg import Twist
import matplotlib.pyplot as plt

def publish_velocities(file_L, file_F, topic_name_L, topic_name_F):
    rospy.init_node('velocity_publisher')

    velocity_pub_L = rospy.Publisher(topic_name_L, Twist, queue_size=10)
    velocity_pub_F = rospy.Publisher(topic_name_F, Twist, queue_size=10)

    rate = rospy.Rate(10)

    time_steps_L = [] 
    linear_velocities_L = []  
    angular_velocities_L = []  

    time_steps_F = []  
    linear_velocities_F = [] 
    angular_velocities_F = []  

    try:
        with open(file_L, 'r') as csvfile_L, open(file_F, 'r') as csvfile_F:
            reader_L = csv.reader(csvfile_L)
            reader_F = csv.reader(csvfile_F)

            while not rospy.is_shutdown():
                row_L = next(reader_L, None)
                row_F = next(reader_F, None)

                if row_L is not None and len(row_L) == 2:
                    linear_vel_L = float(row_L[0])  / 2
                    angular_vel_L = float(row_L[1])
                    twist_msg_L = Twist()
                    twist_msg_L.linear.x = linear_vel_L
                    twist_msg_L.angular.z = angular_vel_L
                    velocity_pub_L.publish(twist_msg_L)
                    time_steps_L.append(rospy.get_time())
                    linear_velocities_L.append(linear_vel_L)
                    angular_velocities_L.append(angular_vel_L)

                if row_F is not None and len(row_F) == 2:
                    linear_vel_F = float(row_F[0])  / 2
                    angular_vel_F = float(row_F[1])
                    twist_msg_F = Twist()
                    twist_msg_F.linear.x = linear_vel_F
                    twist_msg_F.angular.z = angular_vel_F
                    velocity_pub_F.publish(twist_msg_F)
                    time_steps_F.append(rospy.get_time())
                    linear_velocities_F.append(linear_vel_F)
                    angular_velocities_F.append(angular_vel_F)

                rate.sleep()

    except Exception as e:
        rospy.logerr("Error reading and publishing velocities: %s", str(e))

    # plt.figure(figsize=(10, 5))
    # plt.subplot(2, 1, 1)
    # plt.plot(time_steps_L, linear_velocities_L, label='Linear Velocity (L)')
    # plt.plot(time_steps_F, linear_velocities_F, label='Linear Velocity (F)')
    # plt.xlabel('Time (s)')
    # plt.ylabel('Linear Velocity (m/s)')
    # plt.legend()

    # plt.subplot(2, 1, 2)
    # plt.plot(time_steps_L, angular_velocities_L, label='Angular Velocity (L)')
    # plt.plot(time_steps_F, angular_velocities_F, label='Angular Velocity (F)')
    # plt.xlabel('Time (s)')
    # plt.ylabel('Angular Velocity (rad/s)')
    # plt.legend()

    # plt.tight_layout()
    # plt.show()

if __name__ == '__main__':
    try:
        file_F = 'UF.csv'
        file_L = 'UL.csv'
        topic_name_L = '/robot1/cmd_vel'
        topic_name_F = '/robot2/cmd_vel'

        publish_velocities(file_L, file_F, topic_name_L, topic_name_F)

    except rospy.ROSInterruptException:
        pass
