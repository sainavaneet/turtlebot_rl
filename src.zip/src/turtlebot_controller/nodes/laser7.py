import rospy
import numpy as np
from geometry_msgs.msg import Twist, Pose
from nav_msgs.msg import Odometry
from collections import deque
from tf.transformations import euler_from_quaternion
from std_srvs.srv import Empty
import random
import torch
import torch.nn as nn
import torch.optim as optim
from sensor_msgs.msg import LaserScan
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class QNetwork(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(3, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, output_dim)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

class RobotController:
    def __init__(self):
        self.initialize_ros_nodes()
        self.dist = self.get_distance()

    def initialize_ros_nodes(self):
        rospy.init_node('robot_rl_controller')
        rospy.Subscriber('/robot1/odom', Odometry, self.robot1_odom_callback)
        rospy.Subscriber('/robot2/odom', Odometry, self.robot2_odom_callback)
        self.cmd_vel_robot2 = rospy.Publisher('/robot2/cmd_vel', Twist, queue_size=10)
        self.cmd_vel_robot1 = rospy.Publisher('/robot1/cmd_vel', Twist, queue_size=10)
        self.reset_proxy = rospy.ServiceProxy('gazebo/reset_simulation', Empty)
        self.unpause_proxy = rospy.ServiceProxy('gazebo/unpause_physics', Empty)
        self.pause_proxy = rospy.ServiceProxy('gazebo/pause_physics', Empty)
        self.gamma = 0.97
        self.learning_rate = 0.00025
        self.epsilon_decay = 0.998
        self.min_epsilon = 0.005
        self.memory = deque(maxlen=1000000)
        self.epsilon = 1.0
        self.robot1_x = 0
        self.robot1_y = 0
        self.robot1_theta = 0.0
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
        self.min_laser_distance = float('inf')
        self.q_network = QNetwork(6, 25).to(device)
        self.target_network = QNetwork(6, 25).to(device)
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=self.learning_rate)
        
        
        self.robot1_x = 0.0
        self.robot1_y = 0.0
        self.robot1_theta = 0.0
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
       

        self.k_x =  0.5
        self.k_theta = 0.5
        self.robot1_positions = []
        self.robot2_positions = []
       

        self.fig = plt.figure(figsize=(10, 8))
        self.fig.suptitle('Leader - Follower Tracking', fontsize=12)
        self.ax = self.fig.add_subplot(111, projection='3d' , facecolor=(1,1,1))

    def get_state(self):
        relative_x = self.robot2_x - self.robot1_x
        relative_y = self.robot2_y - self.robot1_y
        relative_theta = self.robot2_theta - self.robot1_theta
        return np.array([relative_x, relative_y, relative_theta])

    def get_reward(self):
        # Constants for tuning the reward function
        POSITION_WEIGHT = 1.0  
        ORIENTATION_WEIGHT = 1.0 
        COLLISION_PENALTY = -1000  
        PERFECT_MIMICRY_REWARD = 100  # bonus for perfect alignment

        # Calculate the positional difference (Euclidean distance)
        position_diff = np.sqrt((self.robot2_x - self.robot1_x)**2 + (self.robot2_y - self.robot1_y)**2)

        # Calculate the absolute difference in orientation
        orientation_diff = abs(self.robot2_theta - self.robot1_theta)
        orientation_diff = min(orientation_diff, 2 * np.pi - orientation_diff)  # shortest angle difference

        # Check for collision (assuming a collision happens if the distance is too small)
        if position_diff < 0.3:  # assuming 0.05 is the minimum distance to avoid a collision
            return COLLISION_PENALTY

        # Construct the reward
        # The reward has a higher value when the differences (position and orientation) are smaller
        reward = -(POSITION_WEIGHT * position_diff + ORIENTATION_WEIGHT * orientation_diff) + linear_velocity_rewared + angular_velocity_rewared
        
        if self.robot1_linear_vel == self.robot2_linear_vel:
            linear_velocity_rewared = 100 
            
        else:
            linear_velocity_rewared = 0
            
        if self.robot1_angular_vel == self.robot2_angular_vel:
            angular_velocity_rewared = 100 
            
        else:
            angular_velocity_rewared = 0
        
        

        # Check if both position and orientation are almost identical, then add a bonus reward
        if position_diff < 0.01 and orientation_diff < 0.05:  # threshold values can be adjusted
            reward += PERFECT_MIMICRY_REWARD

        return reward


    def choose_action(self, state):
        state_np = np.array(state).reshape(1, -1)
        state_tensor = torch.FloatTensor(state_np).to(device)
        if np.random.rand() < self.epsilon:
            return np.random.choice(range(25))
        with torch.no_grad():
            return np.argmax(self.q_network(state_tensor).cpu().data.numpy())

    def robot1_odom_callback(self, msg):
        self.robot1_x = msg.pose.pose.position.x
        self.robot1_y = msg.pose.pose.position.y
        self.robot1_linear_vel = msg.twist.twist.linear.x
        self.robot1_angular_vel = msg.twist.twist.angular.z
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot1_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def robot2_odom_callback(self, msg):
        self.robot2_x = msg.pose.pose.position.x
        self.robot2_y = msg.pose.pose.position.y
        self.robot2_linear_vel = msg.twist.twist.linear.x
        self.robot2_angular_vel = msg.twist.twist.angular.z
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot2_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def get_distance(self):
        x1 = self.robot1_x
        y1 = self.robot1_y
        x2 = self.robot2_x
        y2 = self.robot2_y
        self.dist = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        return self.dist

    def train(self):
        batch_size = 128
        if len(self.memory) < batch_size:
            return None
        
        batch = random.sample(self.memory, batch_size)
        state, action, reward, next_state, done = zip(*batch)
        
        action_indices = [self.action_to_index(a) for a in action]

        state = torch.FloatTensor(np.array(state)).to(device)
        action_indices_tensor = torch.tensor(action_indices, device=device, dtype=torch.long).unsqueeze(1)
        reward = torch.FloatTensor(reward).to(device)
        next_state = torch.FloatTensor(np.array(next_state)).to(device)
        done = torch.FloatTensor(done).to(device)
        
        q_values = self.q_network(state)
        q_value = q_values.gather(1, action_indices_tensor).squeeze(1)
        q_value = q_values.gather(1, action_indices_tensor).squeeze(1)
        next_q_values = self.q_network(next_state)
        next_q_target = self.target_network(next_state)
        next_q_value = next_q_target.gather(1, torch.max(next_q_values, 1)[1].unsqueeze(1)).squeeze(1)
        expected_q_value = reward + self.gamma * next_q_value * (1 - done)
        loss = (q_value - expected_q_value.detach()).pow(2).mean()
        loss = torch.clamp(loss, -1, 1)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        tau = 0.005
        for target_param, param in zip(self.target_network.parameters(), self.q_network.parameters()):
            target_param.data.copy_(tau * param.data + (1.0 - tau) * target_param.data)
        self.epsilon = max(self.epsilon * self.epsilon_decay, self.min_epsilon)
        return loss.item()

    def reset_environment(self):
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
        return self.get_state()

    def step(self, linear_velocity, angular_velocity):
        control_command_robot2 = Twist()
        control_command_robot2.linear.x = linear_velocity
        control_command_robot2.angular.z = angular_velocity
        self.cmd_vel_robot2.publish(control_command_robot2)
        control_command_robot1 = Twist()
        control_command_robot1.linear.x = 0.3
        control_command_robot1.angular.z = 0.3
        self.cmd_vel_robot1.publish(control_command_robot1)
        rospy.sleep(0.1)
        next_state = self.get_state()
        reward = self.get_reward()
        done = False
        return next_state, reward, done


    def mpc_optimization(self, horizon=5):
        state = np.array([self.robot1_x, self.robot1_y, self.robot1_theta, self.robot2_x, self.robot2_y, self.robot2_theta])
        best_reward = float('-inf')
        best_actions = []

        linear_vel_space = np.linspace(0, 0.5, num=10)  
        angular_vel_space = np.linspace(0, 0.5, num=10)  

        for linear_vel in linear_vel_space:
            for angular_vel in angular_vel_space:
                simulated_state = state.copy()
                total_reward = 0

                for _ in range(horizon):
                    simulated_state = self.update_state(simulated_state, linear_vel, angular_vel)
                    total_reward += self.calculate_cost(simulated_state)  

                total_reward += np.random.normal(0, 0.1)  

                if total_reward > best_reward:
                    best_reward = total_reward
                    best_actions.append((linear_vel, angular_vel))

        chosen_action = random.choice(best_actions) if best_actions else (0.0, 0.0)

        return chosen_action




    def update_state(self, state, linear_velocity, angular_velocity, dt=0.1):
        x, y, theta, _, _, _ = state
        x_new = x + linear_velocity * np.cos(theta) * dt
        y_new = y + linear_velocity * np.sin(theta) * dt
        theta_new = theta + angular_velocity * dt
        return np.array([x_new, y_new, theta_new, state[3], state[4], state[5]])

    def calculate_cost(self, state):
        x1, y1, _, x2, y2, _ = state
        dist = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        return (dist - 1)**2

    def reset(self):
        rospy.wait_for_service('gazebo/reset_simulation')
        try:
            self.reset_proxy()
            
        except (rospy.ServiceException) as e:
            rospy.logerr("gazebo/reset_simulation service call failed")

    def save_model(self, path):
        torch.save(self.q_network.state_dict(), path)

    def safe_sleep(self, duration):
        try:
            rospy.sleep(duration)
        except rospy.exceptions.ROSTimeMovedBackwardsException:
            pass

    def action_to_index(self, action):
       
       
        linear_steps = 5
        angular_steps = 5
        linear_index = int((action[0] + 1) / 2 * linear_steps)
        angular_index = int((action[1] + 1) / 2 * angular_steps)
        return linear_index * angular_steps + angular_index

    def control_loop(self):
        max_episode_steps = 150  
        self.get_distance()
        loss = self.train()
        loss = None
        epoch = 0
        while not rospy.is_shutdown():  
            state = self.reset_environment()
            done = False
            episode_reward = 0
            step_count = 0

            while not done:
                action = self.mpc_optimization(horizon=5)
                linear_vel, angular_vel = action
                next_state, reward, done = self.step(linear_vel, angular_vel)
                self.memory.append((state, action, reward, next_state, done))
                episode_reward += reward
                state = next_state
                step_count += 1
                temp_loss = self.train()
                x1 = self.robot1_x
                y1 = self.robot1_y
                
                self.robot1_positions.append((x1, y1, 0))
                self.robot2_positions.append((self.robot2_x, self.robot2_y, 0))

                
                self.ax.plot3D(
                    *zip(*self.robot1_positions), 
                    label='Robot 1', 
                    c='r',  # color of the line
                    linewidth=0.5,  # width of the line
                    marker='o',  # marker shape
                    markersize=4,  # size of the marker; adjust the value as needed
                    linestyle='-',  # style of the line; '-' means a solid line
                )

                # Plotting for Robot 2 with modified attributes
                self.ax.plot3D(
                    *zip(*self.robot2_positions), 
                    label='Robot 2', 
                    c='g',  # color of the line
                    linewidth=0.5,  # width of the line
                    marker='o',  # marker shape
                    markersize=4,  # size of the marker; adjust the value as needed
                    linestyle='-',  # style of the line; '-' means a solid line
                )

                self.ax.set_xlabel('X')
                self.ax.set_ylabel('Y')
                self.ax.set_zlabel('Z')
                self.ax.set_xlim(3, -3)  
                self.ax.set_ylim(3, -3)
                self.ax.set_zlim(4, -4)

                

                plt.pause(0.01)


                if temp_loss is not None:
                    loss = temp_loss
        
                if self.dist < 0.3 or self.dist > 3.0 or step_count >= max_episode_steps or episode_reward < -300:
                    rospy.loginfo("\n" + "->" * 100 + "\n" +
                                "Resetting due to distance or collision or maximum steps reached\n" +
                                "->" * 100)
                    self.reset()
                    self.robot1_positions.clear()  
                    self.robot2_positions.clear()  
                    self.ax.clear()  
                    break
                rospy.loginfo(f"Episode: {epoch+1}, step: {step_count}, action: ({action[0]:.2f}, {action[1]:.2f}), Distance: {self.dist}, Reward: {episode_reward}")


            if epoch % 10 == 0:
                self.target_network.load_state_dict(self.q_network.state_dict())

            
            if (epoch + 1) % 100 == 0:
                self.save_model("/home/navaneet/my_ws/src/turtlebot_controller/nodes/save_model3/model_epoch_{}.pth".format(epoch + 1))
                
                figure_save_path = "/home/navaneet/my_ws/src/turtlebot_controller/nodes/fig_train/figure_epoch_{}.png".format(epoch + 1)
                self.fig.savefig(figure_save_path)

            epoch += 1
            self.safe_sleep(0.1)

if __name__ == '__main__':
    try:
        controller = RobotController()
        # controller.q_network.load_state_dict(torch.load('/home/navaneet/my_ws/src/turtlebot_controller/nodes/save_model/model_epoch_1200.pth'))
        controller.control_loop()
    except rospy.ROSInterruptException:
        rospy.signal_shutdown("Ctrl+C pressed. Stopping robots.")
        pass








    