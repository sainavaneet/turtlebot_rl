import rospy
import numpy as np
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
import do_mpc
from do_mpc.controller import MPC

class FollowerMPC:
    def __init__(self):
        rospy.init_node('follower_mpc')
        rospy.Subscriber('/robot1/odom', Odometry, self.robot1_odom_callback)
        rospy.Subscriber('/robot2/odom', Odometry, self.robot2_odom_callback)
        self.cmd_vel_robot2 = rospy.Publisher('/robot2/cmd_vel', Twist, queue_size=10)
        self.cmd_vel_robot1 = rospy.Publisher('/robot1/cmd_vel', Twist, queue_size=10)
        self.robot1_x = 0.0
        self.robot1_y = 0.0
        self.robot1_theta = 0.0
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
        self.prediction_horizon = 5
        self.control_horizon = 5
        self.dt = 0.1
        self.k_x = 0.5
        self.k_theta = 0.5

        # Create an instance of do-mpc's MPC class
        self.mpc = MPC(n_horizon=self.prediction_horizon, casadi_intg='cvodes')

        # Define the model
        self.create_model()

        # Set up the optimizer and constraints
        self.setup_optimizer()

        # Initialize do-mpc's controller
        self.mpc.setup()

    def robot1_odom_callback(self, msg):
        self.robot1_x = msg.pose.pose.position.x
        self.robot1_y = msg.pose.pose.position.y
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot1_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def robot2_odom_callback(self, msg):
        self.robot2_x = msg.pose.pose.position.x
        self.robot2_y = msg.pose.pose.position.y
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot2_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def create_model(self):
        # Define the system dynamics and model constraints
        self.mpc.set_time(self.dt)
        
        # State variables (x, y, theta) for robot2
        self.mpc.set_variable('_x', self.robot2_x)
        self.mpc.set_variable('_y', self.robot2_y)
        self.mpc.set_variable('_theta', self.robot2_theta)

        # Control inputs (linear velocity, angular velocity)
        self.mpc.set_variable('_v', 0.0)
        self.mpc.set_variable('_omega', 0.0)

        # Kinematic equations (simple differential drive model)
        x_next = self._x + self.dt * (self._v * np.cos(self._theta))
        y_next = self._y + self.dt * (self._v * np.sin(self._theta))
        theta_next = self._theta + self.dt * self._omega

        self.mpc.set_rhs('x', x_next)
        self.mpc.set_rhs('y', y_next)
        self.mpc.set_rhs('theta', theta_next)

    def setup_optimizer(self):
        # Configure the optimizer and constraints (cost function, bounds, etc.)
        self.mpc.set_objective(self.cost_function)

        # Control input bounds
        v_min = -1.0
        v_max = 1.0
        omega_min = -1.0
        omega_max = 1.0

        self.mpc.bounds['lower', '_v'] = v_min
        self.mpc.bounds['upper', '_v'] = v_max
        self.mpc.bounds['lower', '_omega'] = omega_min
        self.mpc.bounds['upper', '_omega'] = omega_max

    def cost_function(self, x, u, p):
        # Define the cost function based on control objectives
        x_error = self.robot1_x - x['_x']
        y_error = self.robot1_y - x['_y']
        theta_error = self.robot1_theta - x['_theta']

        cost = self.k_x * (x_error ** 2 + y_error ** 2) + self.k_theta * (theta_error ** 2)
        return cost

    def solve_mpc(self):


        control_command_robot1 = Twist()
        control_command_robot1.linear.x = 0.2
        control_command_robot1.angular.z = 0.2  
        self.cmd_vel_robot1.publish(control_command_robot1)
        # Set the reference states
        self.mpc.set_reference('states', '_x', self.robot1_x)
        self.mpc.set_reference('states', '_y', self.robot1_y)
        self.mpc.set_reference('states', '_theta', self.robot1_theta)

        # Solve the MPC problem
        self.mpc.solve()

        # Get the optimal control inputs
        v_optimal = self.mpc.get_control_trajectory('_v', 0)
        omega_optimal = self.mpc.get_control_trajectory('_omega', 0)

        # Apply the control inputs to the robot
        control_command = Twist()
        control_command.linear.x = v_optimal
        control_command.angular.z = omega_optimal
        self.cmd_vel_robot2.publish(control_command)

    def control_loop(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            self.solve_mpc()
            rate.sleep()

if __name__ == '__main__':
    try:
        controller = FollowerMPC()
        controller.control_loop()
    except rospy.ROSInterruptException:
        pass
