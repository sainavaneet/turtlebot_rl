import numpy as np

# Define the parametric equations for the lemniscate of Bernoulli
def lemniscate(t):
    x = np.sin(t) / (1 + np.cos(t)**2)
    y = (np.sin(t) * np.cos(t)) / (1 + np.cos(t)**2)
    return x, y

# Generate t values from 0 to 2*pi with more than 1000 points
t_values = np.linspace(0, 2*np.pi, 1001)

# Compute the x and y values for each t
points = [lemniscate(t) for t in t_values]

# Save the points to a file
with open("lemniscate_points.txt", "w") as f:
    for x, y in points:
        f.write(f"{x}, {y}\n")

print("Points saved to lemniscate_points.txt")
