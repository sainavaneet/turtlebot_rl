import rospy
import numpy as np
from geometry_msgs.msg import Twist, Pose
from nav_msgs.msg import Odometry
from collections import deque
from tf.transformations import euler_from_quaternion
from std_srvs.srv import Empty
import random
import torch
import torch.nn as nn
import torch.optim as optim
from sensor_msgs.msg import LaserScan
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class QNetwork(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, output_dim)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

class RobotController:
    def __init__(self):


        self.initialize_ros_nodes()
        self.dist = self.get_distance()

    def initialize_ros_nodes(self):
        rospy.init_node('robot_rl_controller')
        self.linear_velocities = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
        self.angular_velocities = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
        rospy.Subscriber('/robot1/odom', Odometry, self.robot1_odom_callback)
        rospy.Subscriber('/robot2/odom', Odometry, self.robot2_odom_callback)
        self.cmd_vel_robot2 = rospy.Publisher('/robot2/cmd_vel', Twist, queue_size=10)
        self.cmd_vel_robot1 = rospy.Publisher('/robot1/cmd_vel', Twist, queue_size=10)
        self.reset_proxy = rospy.ServiceProxy('gazebo/reset_simulation', Empty)
        self.unpause_proxy = rospy.ServiceProxy('gazebo/unpause_physics', Empty)
        self.pause_proxy = rospy.ServiceProxy('gazebo/pause_physics', Empty)
        self.gamma = 0.97
        self.learning_rate = 0.00025
        self.epsilon_decay = 0.998
        self.min_epsilon = 0.005
        self.memory = deque(maxlen=1000000)
        self.epsilon = 1.0
        self.robot1_x = 0
        self.robot1_y = 0
        self.robot1_theta = 0.0
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
        self.min_laser_distance = float('inf')
        self.q_network = QNetwork(6, 25).to(device)
        self.target_network = QNetwork(6, 25).to(device)

        self.optimizer = optim.Adam(self.q_network.parameters(), lr=self.learning_rate)
        self.robot1_x = 0.0
        self.robot1_y = 0.0
        self.robot1_theta = 0.0
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
       

        self.k_x =  0.5
        self.k_theta = 0.5
        self.robot1_positions = []
        self.robot2_positions = []
       

        self.fig = plt.figure(figsize=(10, 8))
        self.fig.suptitle('Leader - Follower Tracking', fontsize=12)
        self.ax = self.fig.add_subplot(111, projection='3d' , facecolor=(1,1,1))

        


    def get_state(self):
        return np.array([self.robot1_x, self.robot1_y, self.robot1_theta, self.robot2_x, self.robot2_y, self.robot2_theta])


    def get_reward(self):
        
        self.get_distance()
        COLLISION_PENALTY = -1000
        VELOCITY_MATCHING_WEIGHT = 20
        POSITION_WEIGHT = 1.0
        ORIENTATION_WEIGHT = 1.0
        STABLE_FOLLOWING_BONUS = 50  # Hypothetical bonus value for stable following
        NOT_BEHIND_PENALTY = -30

        ideal_distance = 1.0  # The ideal following distance

        orientation_diff = abs(self.robot2_theta - self.robot1_theta)
        orientation_diff = min(orientation_diff, 2 * np.pi - orientation_diff)  # Normalize between 0 and pi

      
        distance_diff = self.dist - ideal_distance
        distance_reward = -np.square(distance_diff)  # Quadratic penalty function

        orientation_reward = np.cos(orientation_diff)  # This function rewards alignment with the leader's orientation

        # Velocity matching reward
        velocity_diff = abs(self.robot2_linear_vel - self.robot1_linear_vel) + abs(self.robot2_angular_vel - self.robot1_angular_vel)
        velocity_matching_reward = velocity_diff  
        reward = (distance_reward * POSITION_WEIGHT +
                orientation_reward * ORIENTATION_WEIGHT +
                velocity_matching_reward * VELOCITY_MATCHING_WEIGHT)

    

    

        return reward




    def choose_action(self, state):
        state_np = np.array(state).reshape(1, -1)
        state_tensor = torch.FloatTensor(state_np).to(device)

        if np.random.rand() < self.epsilon:
            linear_velocity = np.random.uniform(0, 0.5)
            angular_velocity = np.random.uniform(0, 0.5)
            return np.array([linear_velocity, angular_velocity])
        else:
            with torch.no_grad():
                action_values = self.q_network(state_tensor).cpu().data.numpy().flatten()
                action_idx = np.argmax(action_values)
                
                linear_idx = action_idx // 5
                angular_idx = action_idx % 5
                
                # Translate these indices to actual velocity values; you'll need to define this mapping
                linear_velocity = self.linear_velocities[linear_idx]
                angular_velocity = self.angular_velocities[angular_idx]
                
                return np.array([linear_velocity, angular_velocity])



        

    def robot1_odom_callback(self, msg):
        self.robot1_x = msg.pose.pose.position.x
        self.robot1_y = msg.pose.pose.position.y
        self.robot1_linear_vel = msg.twist.twist.linear.x
        self.robot1_angular_vel = msg.twist.twist.angular.z
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot1_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def robot2_odom_callback(self, msg):
        self.robot2_x = msg.pose.pose.position.x
        self.robot2_y = msg.pose.pose.position.y
        self.robot2_linear_vel = msg.twist.twist.linear.x
        self.robot2_angular_vel = msg.twist.twist.angular.z
        orientation_quaternion = msg.pose.pose.orientation
        (_, _, self.robot2_theta) = euler_from_quaternion([orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w])

    def get_distance(self):
        x1 = self.robot1_x
        y1 = self.robot1_y
        x2 = self.robot2_x
        y2 = self.robot2_y
        self.dist = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        return self.dist
    

    def train(self):
        batch_size = 128  # Define your batch size
        if len(self.memory) < batch_size:
            return  # Not enough samples

        # Sample a batch of experiences from memory.
        minibatch = random.sample(self.memory, batch_size)

        # Extract states, actions, rewards, next states, and dones.
        # Convert them to numpy arrays and then to tensors.
        # This ensures we're not creating tensors from a list of numpy arrays.
        states_np = np.array([item[0] for item in minibatch])
        
        actions_np = np.array([item[1] for item in minibatch])
        # print(f"Actions shape (NumPy): {actions_np.shape}") 
        rewards_np = np.array([item[2] for item in minibatch])
        next_states_np = np.array([item[3] for item in minibatch])
        dones_np = np.array([item[4] for item in minibatch])

        states = torch.FloatTensor(states_np).to(device)
        # Convert actions to index format for the new representation
        action_indices = actions_np[:, 0] * 5 + actions_np[:, 1]
        actions = torch.tensor(action_indices, dtype=torch.long, device=device).unsqueeze(1)

        rewards = torch.FloatTensor(rewards_np).to(device)
        next_states = torch.FloatTensor(next_states_np).to(device)
        dones = torch.FloatTensor(dones_np).to(device)


        # In your train method, before the gather call, print the shapes of the involved tensors
        # print(f"Shapes -- states: {states.shape}, actions: {actions.shape}, output: {self.q_network(states).shape}")

        # Then check the output and see where the discrepancy in shapes is occurring.
        current_q_values = self.q_network(states).gather(1, actions)

        

        # Get next Q values from target model on the next state
        next_q_values = self.target_network(next_states).detach()  # We don't need gradients for this
        max_next_q_values = next_q_values.max(1)[0].unsqueeze(1)  # Get maximum Q value of next actions

        # Compute the target Q value: if the episode is done, we don't consider future rewards
        target_q_values = rewards.unsqueeze(1) + (self.gamma * max_next_q_values * (1 - dones.unsqueeze(1)))

        # Compute loss
        loss = torch.nn.functional.mse_loss(current_q_values, target_q_values)

        # Optimize the model
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # Optionally, update the exploration rate
        self.epsilon = max(self.epsilon * self.epsilon_decay, self.min_epsilon)

        return loss.item()  # Return the loss value to track training performance



    def reset_environment(self):
        self.robot2_x = -1.0
        self.robot2_y = 0.0
        self.robot2_theta = 0.0
        return self.get_state()

    def step(self, action):
        control_command_robot2 = Twist()

    # Set velocities from the action chosen
        control_command_robot2.linear.x = action[0]  # Linear velocity from action
        control_command_robot2.angular.z = action[1]  # Angular velocity from action

        # Publish the velocities
        self.cmd_vel_robot2.publish(control_command_robot2)
        control_command_robot1 = Twist()
        control_command_robot1.linear.x = 0.2
        control_command_robot1.angular.z = 0.2  
        self.cmd_vel_robot1.publish(control_command_robot1)
        
        rospy.sleep(0.1)

        next_state = self.get_state()
        reward = self.get_reward()
        done = False
        return next_state, reward, done
    def reset(self):
        rospy.wait_for_service('gazebo/reset_simulation')
        try:
            self.reset_proxy()
        except (rospy.ServiceException) as e:
            rospy.logerr("gazebo/reset_simulation service call failed")
        
    def save_model(self, path):
        torch.save(self.q_network.state_dict(), path)
        
    def safe_sleep(self , duration):
        
        try:
            rospy.sleep(duration)
        except rospy.exceptions.ROSTimeMovedBackwardsException:
            pass

    def control_loop(self):
        max_episode_steps = 200  
        self.get_distance()
        loss = self.train()
        loss = None
        epoch = 0
        while not rospy.is_shutdown():  
            state = self.reset_environment()
            done = False
            episode_reward = 0
            step_count = 0

            while not done:
                action = self.choose_action(state)
                next_state, reward, done = self.step(action)
                self.memory.append((state, action, reward, next_state, done))
                episode_reward += reward
                state = next_state
                step_count += 1
                temp_loss = self.train()
                x1 = self.robot1_x
                y1 = self.robot1_y
                
                self.robot1_positions.append((x1, y1, 0))
                self.robot2_positions.append((self.robot2_x, self.robot2_y, 0))

                
                self.ax.plot3D(
                    *zip(*self.robot1_positions), 
                    label='Robot 1', 
                    c='r',  # color of the line
                    linewidth=0.5,  # width of the line
                    marker='o',  # marker shape
                    markersize=4,  # size of the marker; adjust the value as needed
                    linestyle='-',  # style of the line; '-' means a solid line
                )

                # Plotting for Robot 2 with modified attributes
                self.ax.plot3D(
                    *zip(*self.robot2_positions), 
                    label='Robot 2', 
                    c='g',  # color of the line
                    linewidth=0.5,  # width of the line
                    marker='o',  # marker shape
                    markersize=4,  # size of the marker; adjust the value as needed
                    linestyle='-',  # style of the line; '-' means a solid line
                )

                self.ax.set_xlabel('X')
                self.ax.set_ylabel('Y')
                self.ax.set_zlabel('Z')
                self.ax.set_xlim(3, -3)  
                self.ax.set_ylim(3, -3)
                self.ax.set_zlim(4, -4)

                

                plt.pause(0.01)

                if temp_loss is not None:
                    loss = temp_loss
        
                if self.dist < 0.3 or self.dist > 3.0 or step_count >= max_episode_steps:
                    rospy.loginfo("\n" + "->" * 100 + "\n" +
                                "Resetting due to distance or collision or maximum steps reached\n" +
                                "->" * 100)
                    self.reset()
                    self.robot1_positions.clear()  
                    self.robot2_positions.clear()  
                    self.ax.clear()  
                    break
                rospy.loginfo(f"Episode: {epoch+1}, step: {step_count}, action: ({action[0]:.2f}, {action[1]:.2f}), Distance: {self.dist}, Reward: {episode_reward}")
                # rospy.loginfo(f"Episode: {epoch+1}, step: {step_count}, action: {action}, Distance: {self.dist}, Reward: {episode_reward}")

            if epoch % 10 == 0:
                self.target_network.load_state_dict(self.q_network.state_dict())

            
            if (epoch + 1) % 100 == 0:
                self.save_model("/home/navaneet/my_ws/src/turtlebot_controller/nodes/save_model3/model_epoch_{}.pth".format(epoch + 1))
                figure_save_path = "/home/navaneet/my_ws/src/turtlebot_controller/nodes/fig_train/figure_epoch_{}.png".format(epoch + 1)
                self.fig.savefig(figure_save_path)

            epoch += 1
            
            self.safe_sleep(0.1)

if __name__ == '__main__':
    try:
        controller = RobotController()
        controller.q_network.load_state_dict(torch.load('/home/navaneet/my_ws/src/turtlebot_controller/nodes/save_model3/model_epoch_2000.pth'))
        controller.control_loop()
    except rospy.ROSInterruptException:
        rospy.signal_shutdown("Ctrl+C pressed. Stopping robots.")
        pass
